# Proyecto 6 — Gestión bibliográfica con BibTeX y estilos bibliográficos

Este proyecto muestra cómo administrar referencias bibliográficas en LaTeX usando BibTeX
y cómo cambiar entre distintos estilos bibliográficos.

## Estructura

- `main.tex`: documento principal.
- `referencias.bib`: base de datos bibliográfica.
- `estilos/ieee.tex`: configuración para estilo IEEE.
- `estilos/acm.tex`: configuración para estilo ACM.
- `estilos/springer.tex`: configuración para estilo Springer.
- `estilos/nature.tex`: configuración para estilo Nature.
- `estilos/acs.tex`: configuración para estilo ACS.
- `estilos/apa-biblatex-ejemplo.tex`: ejemplo independiente usando APA con biblatex/biber.

## Cómo cambiar de estilo

En `main.tex`, al final del documento, cambia:

```latex
\input{estilos/ieee}
```

por alguno de estos:

```latex
\input{estilos/acm}
\input{estilos/springer}
\input{estilos/nature}
\input{estilos/acs}
```

## Nota importante sobre APA

APA normalmente se trabaja mejor con `biblatex` y `biber`, por eso se incluye como
ejemplo independiente en:

```text
estilos/apa-biblatex-ejemplo.tex
```

Ese archivo se puede compilar por separado en Overleaf cambiando el compilador a Biber.
