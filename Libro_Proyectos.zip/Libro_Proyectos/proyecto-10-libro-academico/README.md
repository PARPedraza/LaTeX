# Proyecto 10 — Libro académico completo

Proyecto integrador final del libro.

Integra:
- Portada
- Prefacio
- Índice general
- Índice de figuras
- Índice de tablas
- Capítulos independientes
- Bibliografía BibTeX
- Apéndices
- Glosario
- Organización editorial profesional

Diseñado para convertirse en un libro, manual, tesis extensa o material docente.
