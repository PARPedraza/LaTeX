# Proyecto 1 — Documento académico básico

Este proyecto forma parte del laboratorio de proyectos integradores del libro **LaTeX para Universitarios**.

## Objetivo

Construir un documento académico básico con portada, resumen, índice, secciones, listas, tabla, ejemplo de figura, citas y bibliografía.

## Archivos incluidos

```text
proyecto-01-documento-basico/
├── main.tex
├── referencias.bib
├── README.md
├── figuras/
│   └── placeholder.txt
└── secciones/
    ├── introduccion.tex
    ├── desarrollo.tex
    └── conclusiones.tex
```

## Cómo compilar

### En Overleaf

1. Subir la carpeta completa como proyecto.
2. Abrir `main.tex`.
3. Compilar con pdfLaTeX.

### En una instalación local

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

## Actividad sugerida

Modificar la portada, agregar una nueva sección, insertar una imagen real en la carpeta `figuras/` y cambiar las referencias bibliográficas por fuentes relacionadas con una materia universitaria.
