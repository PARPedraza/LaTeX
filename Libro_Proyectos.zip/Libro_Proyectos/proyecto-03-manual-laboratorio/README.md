# Proyecto 3 — Manual de práctica de laboratorio

Plantilla profesional para elaborar manuales de laboratorio en LaTeX.

Incluye:
- Objetivos
- Fundamento teórico
- Materiales
- Procedimiento
- Resultados esperados
- Cuestionario
- Rúbrica de evaluación
