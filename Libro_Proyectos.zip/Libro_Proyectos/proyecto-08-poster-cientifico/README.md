# Proyecto 8 — Póster científico

Plantilla profesional para elaborar un póster científico en LaTeX.

Incluye:
- Formato vertical tipo congreso.
- Título, autores e institución.
- Resumen, introducción, metodología, resultados y conclusiones.
- Bloques visuales.
- Tabla de resultados.
- Espacios para figuras y logos.
- Bibliografía con BibTeX.

## Uso

1. Abrir `main.tex` en Overleaf.
2. Compilar con PDFLaTeX.
3. Sustituir el contenido de ejemplo.
4. Agregar logos en la carpeta `logos/`.
5. Agregar figuras en la carpeta `figuras/`.
