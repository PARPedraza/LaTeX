# Proyecto 9 — Plantilla de tesis universitaria

Plantilla completa para tesis de licenciatura, maestría o doctorado.

Incluye:
- Portada
- Dedicatoria
- Agradecimientos
- Resumen
- Índices automáticos
- Capítulos independientes
- Figuras y tablas
- Bibliografía BibTeX
- Anexos

Estructura preparada para documentos extensos.
