# Proyecto 5 — Artículo científico breve

Plantilla de artículo científico en LaTeX.

Incluye:
- Título, autores y afiliaciones
- Resumen y palabras clave
- Introducción
- Metodología
- Resultados
- Discusión
- Conclusiones
- Bibliografía BibTeX
