# Proyecto 4 — Currículum Vitae Académico

Plantilla profesional para estudiantes, investigadores y profesores.

Incluye:
- Datos personales
- Formación académica
- Experiencia profesional
- Proyectos
- Publicaciones
- Habilidades
- Idiomas
