# Proyecto 6 — Gestión bibliográfica con BibTeX

Proyecto orientado al manejo profesional de referencias bibliográficas.

Incluye:
- Ejemplos de citas en el texto.
- Archivo referencias.bib.
- Estilo IEEE.
- Ejemplo APA (biblatex).
- Ejemplo ACM.
- Referencias de artículos, libros, congresos y páginas web.
