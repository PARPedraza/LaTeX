# Proyecto 7 — Presentación académica con Beamer

Plantilla profesional para crear presentaciones académicas en LaTeX usando Beamer.

Incluye:
- Portada
- Índice automático
- Secciones modulares
- Bloques académicos
- Tabla de resultados
- Diagrama simple
- Diapositiva de metodología
- Diapositiva de conclusiones
- Bibliografía con BibTeX

## Uso

1. Abrir `main.tex` en Overleaf.
2. Compilar con PDFLaTeX.
3. Personalizar título, autores, institución y contenido.
4. Sustituir las figuras de ejemplo en la carpeta `figuras/`.
