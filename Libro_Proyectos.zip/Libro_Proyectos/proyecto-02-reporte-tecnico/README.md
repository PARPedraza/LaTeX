# Proyecto 2 — Reporte técnico profesional

Este proyecto muestra cómo estructurar un reporte técnico en LaTeX con secciones formales, tablas, figuras, referencias cruzadas y bibliografía.

## Archivos principales

- `main.tex`: archivo principal del proyecto.
- `secciones/introduccion.tex`: introducción del reporte.
- `secciones/metodologia.tex`: metodología.
- `secciones/resultados.tex`: resultados con tabla y figura.
- `secciones/conclusiones.tex`: conclusiones.
- `referencias.bib`: archivo bibliográfico.
- `figuras/`: carpeta para imágenes.
- `datos/`: carpeta para datos del reporte.

## Uso

1. Abrir `main.tex` en Overleaf o en un editor local.
2. Compilar con PDFLaTeX.
3. Modificar título, autor, datos, figuras y referencias.
